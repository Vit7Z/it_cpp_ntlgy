#include "DHT_Manager.h"

DHT_Manager::DHT_Manager(int count, ...) {
  sensors_count_ = (count > MAX_SENSORS) ? MAX_SENSORS : count;
  va_list args;
  va_start(args, count);

  for (int i = 0; i < sensors_count_; i++) {
    pins_[i] = va_arg(args, int);
    sensors_[i] = new DHT(pins_[i], DHT22);
    sensors_[i]->begin();
  }

  va_end(args);
}

DHT_Manager::~DHT_Manager() {
  for (int i = 0; i < sensors_count_; i++) {
    delete sensors_[i];
  }
}

// Temperature
float DHT_Manager::GetMaxTemp() {
  float t = -40;

  for (int i = 0; i < sensors_count_; i++) {
    float temp_t = sensors_[i]->readTemperature(false);
    t = (t > temp_t) ? t : temp_t;
  }
  return t;
}

float DHT_Manager::GetAvgTemp() {
  float t = 0;

  for (int i = 0; i < sensors_count_; i++) {
    t += sensors_[i]->readTemperature(false);
  }
  t /= sensors_count_;
  return t;
}

float DHT_Manager::GetMinTemp() {
  float t = 100;

  for (int i = 0; i < sensors_count_; i++) {
    float temp_t = sensors_[i]->readTemperature(false);
    t = (t < temp_t) ? t : temp_t;
  }
  return t;
}

// Humidity
float DHT_Manager::GetMaxHumidity() {
  float h = 0;

  for (int i = 0; i < sensors_count_; i++) {
    float temp_h = sensors_[i]->readHumidity();
    h = (h > temp_h) ? h : temp_h;
  }
  return h;
}

float DHT_Manager::GetAvgHumidity() {
  float h = 0;

  for (int i = 0; i < sensors_count_; i++) {
    h += sensors_[i]->readHumidity();
  }
  h /= sensors_count_;
  return h;
}

float DHT_Manager::GetMinHumidity() {
  float h = 100;
  
  for (int i = 0; i < sensors_count_; i++) {
    float temp_h = sensors_[i]->readHumidity();
    h = (h < temp_h) ? h : temp_h;
  }
  return h;
}