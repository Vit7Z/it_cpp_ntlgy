#ifndef DHT_MANAGER_H
#define DHT_MANAGER_H

#include "DHT.h"

#define MAX_SENSORS 6

class DHT_Manager {
public:
  DHT_Manager(int count, ...);
  ~DHT_Manager();

  float GetMaxTemp();
  float GetAvgTemp();
  float GetMinTemp();

  float GetMaxHumidity();
  float GetAvgHumidity();
  float GetMinHumidity();

private:
  int sensors_count_;
  int pins_[MAX_SENSORS];
  DHT* sensors_[MAX_SENSORS];
};

#endif