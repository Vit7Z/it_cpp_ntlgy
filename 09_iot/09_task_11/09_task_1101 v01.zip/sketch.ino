#include "DHT_Manager.h"

//Для изменения количества датчиков, необходимо изменить первую цифру 
// в объекте dhts в диапазоне 1...6. Сейчас установлено - 4. Значения получаемые от 
//датчиков на pin 6 и pin 7 в расчетах не учитываются.
//При изменении первой цифры (назначении параметров DHT) необходимо учитывать,
// что датчики "обрезаются" (не учитываются их параметры в вычислениях) слева.
//

DHT_Manager dhts(4, 2, 3, 4, 5, 6, 7);

void setup() {
  Serial.begin(9600);
}

void loop() {
  Serial.print("-- Температура: ");
  Serial.print("Мин: ");
  Serial.print(dhts.GetMinTemp());
  Serial.print("°C;   Средн.: ");
  Serial.print(dhts.GetAvgTemp());
  Serial.print("°C;   Макс: ");
  Serial.print(dhts.GetMaxTemp());
  Serial.println("°C.");

  Serial.print("-- Влажность: ");
  Serial.print("Мин: ");
  Serial.print(dhts.GetMinHumidity());
  Serial.print("%;    Средн.: ");
  Serial.print(dhts.GetAvgHumidity());
  Serial.print("%;    Макс: ");
  Serial.print(dhts.GetMaxHumidity());
  Serial.println("%");
  Serial.println("       ");

  delay(2000);
}
