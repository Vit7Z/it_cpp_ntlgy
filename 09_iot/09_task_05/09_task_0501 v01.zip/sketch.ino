#include <LiquidCrystal.h>
#include "tempr_sensor.h"

#define DELAY 100

const uint8_t kRows {3};
const uint8_t kCols {10};

LiquidCrystal lcd(7, 6, 5, 4, 3, 2);

TemprSensor t_sens[] = {
  TemprSensor(A0),
  TemprSensor(A1),
  TemprSensor(A2)
};

float measured_value[kRows][kCols];
float average_value[kRows];

void GetAverageValue(float arr_1[][kCols], uint8_t rows, uint8_t cols, float arr_2[]) {
  for (uint8_t i = 0; i < rows; i++) {
    arr_2[i] = 0;
    for (uint8_t j = 0; j < cols; j++) {
      arr_2[i] += arr_1[i][j];
    }
    arr_2[i] /= cols;
  }
}

void SetStartScreen() {
  lcd.setCursor(0, 0);
  lcd.print("L ");
  lcd.setCursor(8, 0);
  lcd.print("H ");
  lcd.setCursor(0, 1);
  lcd.print("AVG ");
}

void PrintValueOnScreen(uint8_t x, uint8_t y, float value, uint8_t l) {
  lcd.setCursor(x, y);
  lcd.print("   ");
  lcd.setCursor(x, y);
  lcd.print(value, l);
}

void setup() {
  Serial.begin(9600);

  lcd.begin(16, 2);
  lcd.clear();
  SetStartScreen();
}

void loop() {
  for (uint8_t i = 0; i < kRows; i++) {
    for (uint8_t j = 0; j < kCols; j++) {
      measured_value[i][j] = t_sens[i].GetTemperatureCels();
    }
    delay(DELAY);
  }

  GetAverageValue(measured_value, kRows, kCols, average_value);

  float min_temp = min(min(average_value[0], average_value[1]), average_value[2]);
  float max_temp = max(max(average_value[0], average_value[1]), average_value[2]);
  float avg_temp = (average_value[0] + average_value[1] + average_value[2]) / kRows;

  PrintValueOnScreen(2, 0, min_temp, 1);
  PrintValueOnScreen(10, 0, max_temp, 1);
  PrintValueOnScreen(4, 1, avg_temp, 1);
}