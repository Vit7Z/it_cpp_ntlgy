/*
При помощи клавиш "Вверх", "Вниз" необходимо установить время свечения светодиода 2…10 (в сек.). 
Время идет «по кругу».
Нажатием кнопки подтверждается установленное время свечения, появляется надпись «Ok».
На датчике движения устанавливаем срабатывание, светодиод должен гореть в течение установленного времени.
*/

#include <LiquidCrystal.h>
#include "joystick.h"
#include "pir_motion_sensor.h"
#include "led.h"

LiquidCrystal lcd(7, 6, 5, 4, 3, 2);
Joystick joystick_1 (A4, A5, A3);
PirMotionSensor pm_sensor_1 (12);
Led led_1 (13);

uint8_t lag_time_crnt {2};
uint8_t lag_time_old {2};
unsigned long lag_start = 0;
bool is_on = false;

String text {"Set lag:"};

void setup() {
  lcd.begin(16, 2);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(text);
  Serial.begin(9600);
}

void PrintOnLcd(String txt, uint8_t x, uint8_t y) {
  lcd.setCursor(x, y);
  lcd.print(txt);
}

void LedControl() {
  if (is_on && (millis() - lag_start >= lag_time_crnt * 1000)) {
    led_1.TurnOff();
    is_on = false;
  }
}

void loop() {
  joystick_1.GetButtonStatus();
  joystick_1.GetY();

  if (joystick_1.delta_y != 0) {
    lag_time_old = lag_time_crnt;
    lag_time_crnt += joystick_1.delta_y;
    PrintOnLcd("  ", 12, 0);
  }

  if (lag_time_crnt > 10) {
    lag_time_crnt = 2;
    PrintOnLcd(" ", 10, 0);
  }

  if (lag_time_crnt < 2) {
    lag_time_crnt = 10;
  }

  if (lag_time_crnt == 9 && lag_time_old == 10) {
    PrintOnLcd(" ", 10, 0);
  }

  PrintOnLcd(String(lag_time_crnt), 9, 0);

  if (joystick_1.btn_status_crnt == 1) {
    PrintOnLcd("Ok", 12, 0);
  }

  pm_sensor_1.GetStatus();

  if (pm_sensor_1.status == 1 && joystick_1.btn_status_crnt == 1) {
    if (is_on == false) {
      led_1.TurnOn();
      lag_start = millis();
      is_on = true;
    }
  }

  LedControl();
}