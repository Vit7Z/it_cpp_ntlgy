#include "button.h"
#define SEG_COUNT 7

const int pinButton = 9;
const int pinSeg[] = {2, 3, 4, 5, 6, 7, 8};
uint8_t count {0};

byte numberSegments[] = {
  0b11000000, //0
  0b11111001, //1
  0b10100100, //2
  0b10110000, //3
  0b10011001, //4
  0b10010010, //5
  0b10000010, //6
  0b11111000, //7
  0b10000000, //8
  0b10010000, //9
  0b10001000, //A
  0b10000011, //b
  0b11000110, //C
  0b10100001, //d
  0b10000110, //E
  0b10001110 //F
};

Button btn_1(pinButton);

//----------------------------------------------
void setup() {
  for (int i = 0; i < SEG_COUNT; i++) {
    pinMode(pinSeg[i], OUTPUT);
    digitalWrite(pinSeg[i], LOW);
  }

  btn_1.begin();
  Serial.begin(9600);
}

void loop() {
  int mask;
  boolean enableSegment;

  if (btn_1.wasPressed()) {
    count++;
  }

  if (count > 15) {
    count = 0;
  }

  mask = numberSegments[count];

  for (int i = 0; i < SEG_COUNT; i++) {
    enableSegment = bitRead(mask, i);
    digitalWrite(i + 2, enableSegment);
  }
}